# POS-Tagging-Sample
This is my first code on trying some basics on nltk library. 

The data is taken from kaggle : https://www.kaggle.com/datasnaek/youtube-new#GBvideos.csv. It has information for each video about when it was in the trending list, tittle of the video, channel that video belongs to,likes , dislikes etc. For this project purpose, we are restricting to US region only, however I did some eda on this and made a tableau dashboard including other regions as well : https://public.tableau.com/views/YoutubeTrendAnalysis/YoutubeTrendAnalysis?:display_count=y&:origin=viz_share_link

This was the dataset used for one of my projects in summer semester, to see various trends on youtube. We further discussed about how using nltk, can we build a system that can provide what tags, title belonging to particular category can be useful and trend the most  Business Application would be that such a system would help the companies and youtubers to make sure they are applying correct tags and adding necessary elements to their tittle which can help them in making their video being watched by maximum users
